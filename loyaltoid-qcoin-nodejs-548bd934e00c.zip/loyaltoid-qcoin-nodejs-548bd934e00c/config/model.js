import mongoose from 'mongoose';
mongoose.connect(process.env.MONGODB_URI, {
    useNewUrlParser: true,
    useUnifiedTopology: true
});

const dataSchema = new mongoose.Schema({
    hash: {
        required: true,
        type: String
    },
    message: {
        required: true,
        type: String
    },
    coin: {
        required: true,
        type: String
    },
})

export default mongoose.model('TransactionMemo', dataSchema);