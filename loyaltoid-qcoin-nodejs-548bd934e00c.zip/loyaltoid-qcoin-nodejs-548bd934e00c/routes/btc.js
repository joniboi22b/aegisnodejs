
import pkgaxios from 'axios';
const { get, post } = pkgaxios;
import { Router } from 'express';
var router = Router();
import dotenv from 'dotenv';
dotenv.config()
import { ok2, fail2 } from '../config/resformat.js';
import { bitcoin } from '../config/wallet_info.js';
import bitcore from 'bitcore-lib';
import { validate } from 'bitcoin-address-validation';
import bitcoinjs from 'bitcoinjs-lib';
import * as ecc from 'tiny-secp256k1';
import { ECPairFactory } from 'ecpair';
import sb from 'satoshi-bitcoin';
import mongoose from 'mongoose';
import Model from '../config/model.js';
import bip39 from 'bip39';
import { BIP32Factory } from 'bip32';

const ECPair = ECPairFactory(ecc);
const bip32 = BIP32Factory(ecc);

router.post('/createSegwitWallet', function (req, res) {

    try {
        const mnemonic = req.body.passphrase;

        var value = Buffer.from(mnemonic.replace(/-/g, ' '));
        var hash = bitcore.crypto.Hash.sha256(value);
        var bn = bitcore.crypto.BN.fromBuffer(hash);
        var bitcoinPb = new bitcore.PrivateKey(bn, bitcore.Networks.mainnet).toAddress().toString();
        var bitcoinPk = new bitcore.PrivateKey(bn, bitcore.Networks.mainnet).toWIF();

        const network_bitcoin = bitcoinjs.networks.bitcoin;
        const path_btc = `m/84'/0'/0'/0`;
        const seed = bip39.mnemonicToSeedSync(mnemonic);
        let root = bip32.fromSeed(seed, network_bitcoin);
        let newAccount_bitcoin = root.derivePath(path_btc);
        let node = newAccount_bitcoin.derive(0);
        let btcAddress = bitcoinjs.payments.p2wpkh({
            pubkey: node.publicKey,
            network: network_bitcoin,
        }).address;

        var wallet = [
            {
                segwit_address: btcAddress,
                segwit_address_url: bitcoin("address/" + btcAddress).explorer,
                segwit_privateKey: node.toWIF(),
                legacy_address: bitcoinPb,
                legacy_address_url: bitcoin("address/" + bitcoinPb).explorer,
                legacy_privateKey: bitcoinPk,
                mnemonic: mnemonic.split(" "),
            }
        ]

        // var wallet = [
        //     {
        //         address: btcAddress,
        //         address_url: bitcoin("address/" + btcAddress).explorer,
        //         privateKey: node.toWIF(),
        //         mnemonic: mnemonic.split(" "),
        //     }
        // ]

        ok2(req.headers.authorization, "createWallet", 'SUCCESSFUL', bitcoin().symbol, bitcoin().name, wallet, res);

    } catch (e) {
        fail2(req.headers.authorization, "createWallet", 'UNSUCCESSFUL', bitcoin().symbol, bitcoin().name, e.message, res);

    }
});

router.post('/createWallet', function (req, res) {

    try {
        const mnemonic = req.body.passphrase;

        var value = Buffer.from(mnemonic.replace(/-/g, ' '));
        var hash = bitcore.crypto.Hash.sha256(value);
        var bn = bitcore.crypto.BN.fromBuffer(hash);
        var bitcoinPb = new bitcore.PrivateKey(bn, bitcore.Networks.mainnet).toAddress().toString();
        var bitcoinPk = new bitcore.PrivateKey(bn, bitcore.Networks.mainnet).toWIF();

        // const network_bitcoin = bitcoinjs.networks.bitcoin;
        // const path_btc = `m/84'/0'/0'/0`;
        // const seed = bip39.mnemonicToSeedSync(mnemonic).slice(0, 32);
        // let root = bip32.fromSeed(seed, network_bitcoin);
        // let newAccount_bitcoin = root.derivePath(path_btc);
        // let node = newAccount_bitcoin.derive(0).derive(0);
        // let btcAddress = bitcoinjs.payments.p2wpkh({
        //     pubkey: node.publicKey,
        //     network: network_bitcoin,
        // }).address;
        // console.log(btcAddress);

        // var wallet = [
        //     {
        //         segwit_address: btcAddress,
        //         segwit_address_url: bitcoin("address/" + btcAddress).explorer,
        //         segwit_privateKey: node.toWIF(),
        //         legacy_address: bitcoinPb,
        //         legacy_address_url: bitcoin("address/" + bitcoinPb).explorer,
        //         legacy_privateKey: bitcoinPk,
        //         mnemonic: mnemonic.split(" "),
        //     }
        // ]

        var wallet = [
            {
                address: bitcoinPb,
                address_url: bitcoin("address/" + bitcoinPb).explorer,
                privateKey: bitcoinPk,
                mnemonic: mnemonic.split(" "),
            }
        ]

        ok2(req.headers.authorization, "createWallet", 'SUCCESSFUL', bitcoin().symbol, bitcoin().name, wallet, res);

    } catch (e) {
        fail2(req.headers.authorization, "createWallet", 'UNSUCCESSFUL', bitcoin().symbol, bitcoin().name, e.message, res);

    }
});

router.post('/importSegwitWallet', function (req, res) {

    try {
        var pass = req.body.passphrase;

        if (!bip39.validateMnemonic(pass)) {
            fail2(req.headers.authorization, "importWallet", 'UNSUCCESSFUL', bitcoin().symbol, bitcoin().name, "Invalid passphrase", res);

        } else {
            var value = Buffer.from(pass.replace(/-/g, ' '));
            var hash = bitcore.crypto.Hash.sha256(value);
            var bn = bitcore.crypto.BN.fromBuffer(hash);
            var bitcoinPb = new bitcore.PrivateKey(bn, bitcore.Networks.mainnet).toAddress().toString();
            var bitcoinPk = new bitcore.PrivateKey(bn, bitcore.Networks.mainnet).toWIF();

            const network_bitcoin = bitcoinjs.networks.bitcoin;
            const path_btc = `m/84'/0'/0'/0`;
            const seed = bip39.mnemonicToSeedSync(pass);
            let root = bip32.fromSeed(seed, network_bitcoin);
            let newAccount_bitcoin = root.derivePath(path_btc);
            let node = newAccount_bitcoin.derive(0);
            let btcAddress = bitcoinjs.payments.p2wpkh({
                pubkey: node.publicKey,
                network: network_bitcoin,
            }).address;

            var wallet = [
                {
                    segwit_address: btcAddress,
                    segwit_address_url: bitcoin("address/" + btcAddress).explorer,
                    segwit_privateKey: node.toWIF(),
                    legacy_address: bitcoinPb,
                    legacy_address_url: bitcoin("address/" + bitcoinPb).explorer,
                    legacy_privateKey: bitcoinPk,
                }
            ]

            // var wallet = [
            //     {
            //         address: bitcoinPb,
            //         address_url: bitcoin("address/" + bitcoinPb).explorer,
            //         privateKey: bitcoinPk,
            //     }
            // ]

            ok2(req.headers.authorization, "importWallet", 'SUCCESSFUL', bitcoin().symbol, bitcoin().name, wallet, res);
        }

    } catch (e) {
        fail2(req.headers.authorization, "importWallet", 'UNSUCCESSFUL', bitcoin().symbol, bitcoin().name, e.message, res);

    }
});

router.post('/importWallet', function (req, res) {

    try {
        var pass = req.body.passphrase;

        if (!bip39.validateMnemonic(pass)) {
            fail2(req.headers.authorization, "importWallet", 'UNSUCCESSFUL', bitcoin().symbol, bitcoin().name, "Invalid passphrase", res);

        } else {
            var value = Buffer.from(pass.replace(/-/g, ' '));
            var hash = bitcore.crypto.Hash.sha256(value);
            var bn = bitcore.crypto.BN.fromBuffer(hash);
            var bitcoinPb = new bitcore.PrivateKey(bn, bitcore.Networks.mainnet).toAddress().toString();
            var bitcoinPk = new bitcore.PrivateKey(bn, bitcore.Networks.mainnet).toWIF();

            // const network_bitcoin = bitcoinjs.networks.bitcoin;
            // const path_btc = `m/84'/0'/0'/0`;
            // const seed = bip39.mnemonicToSeedSync(pass).slice(0, 32);
            // let root = bip32.fromSeed(seed, network_bitcoin);
            // let newAccount_bitcoin = root.derivePath(path_btc);
            // let node = newAccount_bitcoin.derive(0).derive(0);
            // let btcAddress = bitcoinjs.payments.p2wpkh({
            //     pubkey: node.publicKey,
            //     network: network_bitcoin,
            // }).address;

            // var wallet = [
            //     {
            //         segwit_address: btcAddress,
            //         segwit_address_url: bitcoin("address/" + btcAddress).explorer,
            //         segwit_privateKey: node.toWIF(),
            //         legacy_address: bitcoinPb,
            //         legacy_address_url: bitcoin("address/" + bitcoinPb).explorer,
            //         legacy_privateKey: bitcoinPk,
            //     }
            // ]

            var wallet = [
                {
                    address: bitcoinPb,
                    address_url: bitcoin("address/" + bitcoinPb).explorer,
                    privateKey: bitcoinPk,
                }
            ]

            ok2(req.headers.authorization, "importWallet", 'SUCCESSFUL', bitcoin().symbol, bitcoin().name, wallet, res);
        }

    } catch (e) {
        fail2(req.headers.authorization, "importWallet", 'UNSUCCESSFUL', bitcoin().symbol, bitcoin().name, e.message, res);

    }
});

router.post('/getBalanceByAddress', async function (req, res) {
    try {

        const address = req.body.address;

        const validAddress = validate(address);

        if (!validAddress || null || undefined) {
            fail2(req.headers.authorization, "getBalanceByAddress", 'UNSUCCESSFUL', bitcoin().symbol, bitcoin().name, "Invalid Address", res);
        } else {
            const url = `https://api.bitcore.io/api/${bitcoin().symbol}/mainnet/address/${address}/balance`;
            const balance = await get(url).catch((e) => {
                fail2(req.headers.authorization, "getBalanceByAddress", 'UNSUCCESSFUL', bitcoin().symbol, bitcoin().name, e.message, res);
            })

            const bal = (balance.data.balance) / 100000000
            const balConfirmed = (balance.data.confirmed) / 100000000
            const balUnconfirmed = (balance.data.unconfirmed) / 100000000

            var wallet = [
                {
                    address: address,
                    address_url: bitcoin("address/" + address).explorer,
                    balance: parseInt(balance.data.balance),
                    decimal: parseInt(bitcoin(address).decimal),
                    symbol: bitcoin().symbol,
                    full_balance: bal + " " + bitcoin().symbol,
                    full_balance_float: parseFloat(bal),
                    full_confirmed: parseFloat(balConfirmed),
                    full_unconfrimed: parseFloat(balUnconfirmed)
                }
            ];

            ok2(req.headers.authorization, "getBalanceByAddress", 'SUCCESSFUL', bitcoin().symbol, bitcoin().name, wallet, res);
        }
    } catch (e) {
        fail2(req.headers.authorization, "getBalanceByAddress", 'UNSUCCESSFUL', bitcoin().symbol, bitcoin().name, e.message, res);

    }
});

function timeConverter(UNIX_timestamp) {
    var a = new Date(UNIX_timestamp);

    var months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    var year = a.getFullYear();
    var month = a.getMonth() + 1;
    var date = a.getDate();
    var hour = a.getHours();
    var min = a.getMinutes();
    var sec = a.getSeconds();
    var time = year + '-' + month + '-' + date + ' ' + hour + ':' + min + ':' + sec;
    return time;
}

function senderReceiver(addrOne, address) {

    var type;

    if (addrOne === address) {
        type = "Send";
        return type;
    } else {
        type = "Receive";
        return type;
    }
}

async function fetchMongo(data) {
    //message
    const docs = await Model.find({ hash: data, coin: bitcoin().name }).exec();

    // MongoDB may return the docs in any order unless you explicitly sort
    return docs.map((doc) => doc.message);
}


router.post('/getTransactionByAddress', async function (req, res) {

    try {
        const address = req.body.address;

        const validAddress = validate(address);

        if (!validAddress) {

            fail2(req.headers.authorization, "getTransactionByAddress", 'UNSUCCESSFUL', bitcoin().symbol, bitcoin().name, "Invalid Address", res);

        } else {
            // transaction list
            const url = `https://api.bitcore.io/api/${bitcoin().symbol}/mainnet/address/${address}/txs`;
            const tx = await get(url).catch((e) => {
                fail2(req.headers.authorization, "getTransactionByAddress", 'UNSUCCESSFUL', bitcoin().symbol, bitcoin().name, e.message, res);
            });

            const fruits = [];

            for (var i = 0; i < tx.data.length; i++) {

                // get transaction time
                const urls = `https://api.bitcore.io/api/${bitcoin().symbol}/mainnet/tx/${tx.data[i].mintTxid}`;
                const txs = await get(urls).catch((e) => {
                    fail2(req.headers.authorization, "getTransactionByAddress", 'UNSUCCESSFUL', bitcoin().symbol, bitcoin().name, e.message, res);
                });
                const time = new Date(txs.data.blockTime).getTime();

                // console.log(time);
                // get transaction sender and receiver
                const urltx = process.env.BLOCKDAEMON + `account/${address}/txs`;
                const txstx = await get(urltx, {
                    headers: {
                        "authorization": "Bearer " + process.env.BLOCKDAEMON_KEY
                    }
                }).catch((e) => {
                    fail2(req.headers.authorization, "getTransactionByAddress", 'UNSUCCESSFUL', bitcoin().symbol, bitcoin().name, e.message, res);
                });

                const sender = txstx.data.items[i].operations.script.detail.inputs[0].address;
                const receiver = txstx.data.items[i].operations.script.detail.outputs[0].address;
                const amount = (txstx.data.items[i].operations.script.detail.outputs[0].value);

                // type
                const type = senderReceiver(sender, address);

                const gas = txs.data.fee;
                const gas_value_full = txs.data.fee / 100000000;

                fruits.push({
                    type: type,
                    timestamp: time / 1000,
                    timestamp_text: timeConverter(time),
                    chain: bitcoin().symbol,
                    sender: sender,
                    receiver: receiver,
                    amount: parseInt(amount),
                    full_amount: amount / 100000000 + " " + bitcoin().symbol,
                    gas: parseInt(gas),
                    gas_value_full: parseFloat(gas_value_full) + " " + bitcoin().symbol,
                    coinbase: tx.data[i].coinbase,
                    mintIndex: tx.data[i].mintIndex,
                    spentTxid: tx.data[i].spentTxid,
                    mintTxid: tx.data[i].mintTxid,
                    mintHeight: tx.data[i].mintHeight,
                    spentHeight: tx.data[i].spentHeight,
                    script: tx.data[i].script,
                    balance: parseInt(tx.data[i].value) / 100000000,
                    full_balance: (tx.data[i].value / 100000000) + " " + bitcoin().symbol,
                    decimal: parseInt(bitcoin().decimal),
                    confirmations: txs.data.confirmations,
                    message: (await fetchMongo(tx.data[i].mintTxid)).toString()
                });
            }

            var wallet = [
                {
                    address: address,
                    address_url: bitcoin("address/" + address).explorer,
                    transactions: fruits
                }
            ];

            ok2(req.headers.authorization, "getTransactionByAddress", 'SUCCESSFUL', bitcoin().symbol, bitcoin().name, wallet, res);
        }


    } catch (e) {
        fail2(req.headers.authorization, "getTransactionByAddress", 'UNSUCCESSFUL', bitcoin().symbol, bitcoin().name, e.message, res);

    }
});

router.post('/getTransactionByTxHash', async function (req, res) {

    try {
        const txHash = req.body.txHash;

        const url = `https://api.bitcore.io/api/${bitcoin().symbol}/mainnet/tx/${txHash}`;
        const tx = await get(url).catch((e) => {
            fail2(req.headers.authorization, "getTransactionByTxHash", 'UNSUCCESSFUL', bitcoin().symbol, bitcoin().name, e.message, res);
        });

        const time = new Date(tx.data.blockTime).getTime();

        const urltx = bitcoin("rawtx/" + txHash).explorer;
        const txstx = await get(urltx).catch((e) => {
            fail2(req.headers.authorization, "getTransactionByTxHash", 'UNSUCCESSFUL', bitcoin().symbol, bitcoin().name, e.message, res);
        });

        const sender = txstx.data.out[1].addr;
        const receiver = txstx.data.out[0].addr;

        const gas = tx.data.fee;
        const gas_value_full = tx.data.fee / 100000000;

        // console.log((await fetchMongo(tx.data.txid)).toString());

        var wallet = [
            {
                timestamp: time / 1000,
                timestamp_text: timeConverter(time),
                tx: tx.data.txid,
                sender: sender,
                receiver: receiver,
                full_url_tx: bitcoin(tx.data.txid).tx_explorer,
                block: tx.data.blockHeight,
                block_confirmation: tx.data.confirmations,
                amount: tx.data.value,
                decimal: parseInt(bitcoin().decimal),
                full_amount: (tx.data.value / 100000000) + " " + bitcoin().symbol,
                full_amount_float: parseFloat(tx.data.value / 100000000),
                gas: parseInt(gas),
                full_gas: (gas_value_full) + " " + bitcoin().symbol,
                full_gas_float: parseFloat(tx.data.fee / 100000000),
                message: (await fetchMongo(tx.data.txid)).toString()
            }
        ];

        ok2(req.headers.authorization, "getTransactionByTxHash", 'SUCCESSFUL', bitcoin().symbol, bitcoin().name, wallet, res);
    } catch (e) {
        fail2(req.headers.authorization, "getTransactionByTxHash", 'UNSUCCESSFUL', bitcoin().symbol, bitcoin().name, e.meesage, res);
    }
});

router.post('/gasEstimate', async function (req, res) {

    try {
        // const privateKey = req.body.privKey;
        const sender = req.body.sender;
        const amount = req.body.amount;
        const receiver = req.body.receiver;
        // const fee = req.body.fee;
        // const message = req.body.message;

        const validSender = validate(sender);
        const validReceiver = validate(receiver);

        if (!(validSender && validReceiver) || undefined || null) {
            fail2(req.headers.authorization, "sendTransaction", 'UNSUCCESSFUL', bitcoin().symbol, bitcoin().name, "Invalid Address", res);

        } else {
            // const keypair = ECPair.fromWIF(
            //     privateKey,
            //     bitcoinjs.networks.bitcoin
            // );

            const utxos = await get(
                `https://api.bitcore.io/api/BTC/mainnet/address/${sender}/?unspent=true`
            ).catch((e) => {
                fail2(req.headers.authorization, "gasEstimate", 'UNSUCCESSFUL', bitcoin().symbol, bitcoin().name, e.message, res);
            });

            const tx = new bitcoinjs.Psbt(bitcoinjs.networks.bitcoin);

            let inputs = [];

            let totalValue = 0;

            for (let i = 0; i < utxos.data.length; i++) {

                const nonWitnessData = { "jsonrpc": "1.0", "id": "curltest", "method": "getrawtransaction", "params": [utxos.data[i].mintTxid, false] };

                const nonWitnessutxo = await post(process.env.QUICKNODE_BITCOIN, nonWitnessData, {
                    // headers: {
                    //     "authorization": "Bearer " + process.env.BLOCKDAEMON_KEY
                    // }
                }).catch((e) => {
                    fail2(req.headers.authorization, "gasEstimate", 'UNSUCCESSFUL', bitcoin().symbol, bitcoin().name, e.message, res);
                });

                // console.log(JSON.stringify(nonWitnessutxo.data.result));

                inputs.push({
                    hash: utxos.data[i].mintTxid,
                    index: utxos.data[i].mintIndex,
                    scriptPubKey: utxos.data[i].script,
                    nonWitnessUtxo: Buffer.from(nonWitnessutxo.data.result, 'hex'),
                })

                totalValue += utxos.data[i].value;
            }

            inputs.forEach(element => {
                tx.addInput(element);
            });

            tx.addOutput({
                address: receiver,
                value: sb.toSatoshi(amount)
            });

            tx.addOutput({
                address: sender,
                value: 5000000000 - sb.toSatoshi(amount)
            })

            const size = (tx.txInputs.length * 180) + (tx.txOutputs.length * 34) + 10;
            // console.log(`size :`,size);

            // tx.signAllInputs(keypair);
            // tx.finalizeAllInputs();

            const url = `https://bitcoinfees.earn.com/api/v1/fees/recommended`;
            const tx_gas = await get(url).catch((e) => {
                fail2(req.headers.authorization, "gasEstimate", 'UNSUCCESSFUL', bitcoin().symbol, bitcoin().name, e.message, res);
            });
            var fastestFee = 19.4;
            var halfHourFee = 8.5;
            var hourFee = 1;

            // console.log(fastestFee.toString());

            // const nonWitnessData = { "jsonrpc": "1.0", "id": "curltest", "method": "decoderawtransaction", "params": [tx.extractTransaction().toHex()] };
            // const nonWitnessutxo = await post(process.env.QUICKNODE_BITCOIN, nonWitnessData, {
            //     // headers: {
            //     //     "authorization": "Bearer " + process.env.BLOCKDAEMON_KEY
            //     // }
            // }).catch((e) => {
            //     fail2(req.headers.authorization, "gasEstimate", 'UNSUCCESSFUL', bitcoin().symbol, bitcoin().name, e.message, res);
            // });

            var wallet = [
                {
                    fastestFee: {
                        inSatoshi: parseInt((fastestFee) * size),
                        inBTC: sb.toBitcoin(parseInt((fastestFee) * size))
                    },
                    halfHourFee: {
                        inSatoshi: parseInt((halfHourFee) * size),
                        inBTC: sb.toBitcoin(parseInt((halfHourFee) * size))
                    },
                    hourFee: {
                        inSatoshi: parseInt((hourFee) * size),
                        inBTC: sb.toBitcoin(parseInt((hourFee) * size))
                    }
                }
            ];

            ok2(req.headers.authorization, "gasEstimate", 'SUCCESSFUL', bitcoin().symbol, bitcoin().name, wallet, res);
        }
    } catch (e) {
        fail2(req.headers.authorization, "gasEstimate", 'UNSUCCESSFUL', bitcoin().symbol, bitcoin().name, e.meesage, res);
    }

});

router.post('/sendTransaction', async function (req, res) {

    try {
        const privateKey = req.body.privKey;
        const sender = req.body.sender;
        const amount = req.body.amount;
        const receiver = req.body.receiver;
        const fee = req.body.fee;
        const message = req.body.message;

        const validSender = validate(sender);
        const validReceiver = validate(receiver);

        console.log("Validating address...");
        if (!(validSender && validReceiver) || undefined || null) {
            fail2(req.headers.authorization, "sendTransaction", 'UNSUCCESSFUL', bitcoin().symbol, bitcoin().name, "Invalid Address", res);

        } else {

            console.log("Valid sender and receiver address...");

            const keypair = ECPair.fromWIF(
                privateKey,
                bitcoinjs.networks.bitcoin
            );

            const utxos = await get(
                `https://api.bitcore.io/api/BTC/mainnet/address/${sender}/?unspent=true`
            ).catch((e) => {
                fail2(req.headers.authorization, "sendTransaction", 'UNSUCCESSFUL', bitcoin().symbol, bitcoin().name, e.message, res);
            });

            const tx = new bitcoinjs.Psbt(bitcoinjs.networks.bitcoin);

            let inputs = [];

            let totalValue = 0;

            console.log("Creating input and output...");
            console.log("Calculate utxos...");
            for (let i = 0; i < utxos.data.length; i++) {

                const nonWitnessData = { "jsonrpc": "1.0", "id": "curltest", "method": "getrawtransaction", "params": [utxos.data[i].mintTxid, false] };

                const nonWitnessutxo = await post(process.env.QUICKNODE_BITCOIN, nonWitnessData, {
                    // headers: {
                    //     "authorization": "Bearer " + process.env.BLOCKDAEMON_KEY
                    // }
                }).catch((e) => {
                    fail2(req.headers.authorization, "sendTransaction", 'UNSUCCESSFUL', bitcoin().symbol, bitcoin().name, e.message, res);
                });

                // console.log(JSON.stringify(nonWitnessutxo.data.result));

                inputs.push({
                    hash: utxos.data[i].mintTxid,
                    index: utxos.data[i].mintIndex,
                    scriptPubKey: utxos.data[i].script,
                    nonWitnessUtxo: Buffer.from(nonWitnessutxo.data.result, 'hex'),
                })

                totalValue += utxos.data[i].value;
            }

            inputs.forEach(element => {
                tx.addInput(element);
            });

            tx.addOutput({
                address: receiver,
                value: sb.toSatoshi(amount)
            });

            tx.addOutput({
                address: sender,
                value: totalValue - sb.toSatoshi(amount) - (sb.toSatoshi(fee))
            })

            console.log("Signing all inputs and outputs...");
            tx.signAllInputs(keypair);
            console.log("Finalizing all inputs and outputs...");
            tx.finalizeAllInputs();

            console.log("Signed transaction :" + tx.extractTransaction().toHex());
            console.log("Sending transaction...");
            const signedTx = { "jsonrpc": "1.0", "id": "curltest", "method": "sendrawtransaction", "params": [tx.extractTransaction().toHex()] };
            const send = await post(process.env.QUICKNODE_BITCOIN, signedTx, {
                // headers: {
                //     "authorization": "Bearer " + process.env.BLOCKDAEMON_KEY
                // }
            }).catch((e) => {
                fail2(req.headers.authorization, "sendTransaction", 'UNSUCCESSFUL', bitcoin().symbol, bitcoin().name, e.message, res);
            });

            console.log(`Result: ${send.data.result}`);

            //message db
            mongoose.connect(process.env.MONGODB_URI).then(async () => {

                if (message == null) {
                    const data = new Model({
                        hash: send.data.result,
                        message: "",
                        coin: bitcoin().name
                    })

                    const dataToSave = await data.save();
                } else {
                    const data = new Model({
                        hash: send.data.result,
                        message: message,
                        coin: bitcoin().name
                    })

                    const dataToSave = await data.save();
                }
                // console.log(JSON.stringify(dataToSave));
            }).catch((e) => {
                fail2(req.headers.authorization, "sendTransaction", 'UNSUCCESSFUL', bitcoin().symbol, bitcoin().name, e.message, res);
            });

            var wallet = [
                {
                    txid: send.data.result,
                    chain: bitcoin(sender).symbol,
                    full_url_tx: bitcoin(send.data.result).tx_explorer,
                    value: amount,
                    sender: sender,
                    receiver: receiver,
                    amount_sent: amount + " " + bitcoin(sender).symbol,
                    message: message
                }
            ];

            ok2(req.headers.authorization, "sendTransaction", 'SUCCESSFUL', bitcoin().symbol, bitcoin().name, wallet, res);
        }

    } catch (e) {
        fail2(req.headers.authorization, "sendTransaction", 'UNSUCCESSFUL', bitcoin().symbol, bitcoin().name, e.message, res);
    }
});

// router.post('/sendRawTransaction', async function (req, res, next) {
//     try {
//         const serializedTx = req.body.serializedTx;

//         const signedTx = { "jsonrpc": "1.0", "id": "curltest", "method": "sendrawtransaction", "params": [serializedTx] };
//         const send = await post(process.env.BLOCKDAEMON, signedTx, {
//             headers: {
//                 "authorization": "Bearer " + process.env.BLOCKDAEMON_KEY
//             }
//         });

//         // res.json(send.data.result)

//         var wallet = [
//             {
//                 hash: send.data
//             }
//         ];

//         ok2(req.headers.authorization, "sendRawTransaction", 'SUCCESSFUL', bitcoin().symbol, bitcoin().name, wallet, res);
//     } catch (e) {
//         fail2(req.headers.authorization, "sendRawTransaction", 'UNSUCCESSFUL', bitcoin().symbol, bitcoin().name, "Server Error", res);
//     }

// });

export default router;
